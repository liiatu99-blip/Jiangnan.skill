# Dialogue Calibration for Jiangnan-Adjacent Fanfic

> Goal: fix the common failure mode where dialogue becomes slogan-like, self-conscious, or juvenile. Use high-level craft principles only; do not copy exact lines from copyrighted works.

## Core Diagnosis

Bad fanfic dialogue often names the theme directly:

- “我不当王。”
- “我要改写命运。”
- “我要把这破结局改了。”
- “我是来赴约的。”
- “这次换我守护你们。”

These lines feel like the character knows they are standing in a climax scene. They turn subtext into a poster slogan. Even if the idea is correct, the delivery feels cheap.

## Principle: Let Action Carry the Grand Meaning

If a character refuses kingship, do **not** make them say “我不当王.”

Instead:

- show them ignoring the throne / title / crown / invitation;
- show them picking up a meal card, a dropped weapon, a phone, a coat;
- show them walking toward a friend rather than toward the symbolic seat of power;
- let another character notice the choice silently.

The more epic the meaning, the more ordinary the spoken line should be.

## Dialogue Should Be Contextual, Not Thematic

Good dialogue should sound like something this person would say **inside the immediate situation**, not like a summary of the chapter theme.

Prefer:

- practical instructions: “左边。” “别停。” “枪给我。”
- understated care: “手在抖。” “外套拉上。” “饭凉了。”
- evasive jokes that are almost too small for the scene: “你还欠我钱。” “食堂这会儿不开门。”
- unfinished words: “等一下。” “算了。” “你先……”
- silence plus action: no line at all, just handing over an object.

Avoid:

- thesis statements: “我要做自己。” “我终于明白命运了。”
- theme labels: 王、命运、世界、结局、牺牲、守护、救赎 used as direct declarations;
- over-polished aphorisms that sound written for quotation;
- modern meme punchlines during solemn climaxes unless intentionally undercutting and immediately grounded.

## The Ordinary Line / Epic Context Technique

Put ordinary words against impossible scenery.

Example pattern:

- Context: a gate that erases names opens behind a character.
- Bad line: “我不会让你被世界遗忘。”
- Better line shape: “你名字写错了。” / “这张表我不签。” / “等我一下。”

The line is small; the scene tells the reader what it means.

## Dialogue Density

For a 1000–1500 Chinese-character scene:

- 3–6 dialogue lines is often enough.
- No more than 2 consecutive dialogue lines without narration.
- A climax can have zero grand speech.
- If a line explains the emotional point, delete it and replace it with action or an object.

## Character-Specific Calibration

### Self-deprecating protagonist

- Should dodge, mumble, bargain, joke badly, or ask practical questions.
- In climax, he becomes quieter rather than louder.
- His growth is shown by what he does despite fear, not by heroic declarations.

Useful line shapes:

- “我知道。”
- “你先走。” only if followed by concrete action, not speechifying.
- “饭卡在你那儿。”
- “别回头。”
- “等会儿再骂我。”

### Cold / disciplined companion

- Should speak minimally and precisely.
- Does not explain emotions.
- Care appears as tactical instruction or physical intervention.

Useful line shapes:

- “低头。”
- “三秒。”
- “刀给我。”
- “还没结束。”
- “我看见了。”

### Sharp / red-haired / senior-type character

- Can be cutting, practical, and emotionally evasive.
- Do not overuse quips; one sharp line is enough.

Useful line shapes:

- “活着回来。”
- “别让我收尸。”
- “你最好不是在逞英雄。”
- “我没空等第二次。”

## Revision Checklist for Dialogue

For every line, ask:

1. Could this line be printed on a motivational poster? If yes, cut it.
2. Does the line directly name the theme? If yes, convert to object/action.
3. Is the line something the character says to look cool? If yes, cut it.
4. Would the scene still work if the line were removed? If yes, remove it.
5. Can the line be made more ordinary, practical, or incomplete? Do that.

## Replacement Table

| Too slogan-like | Better direction |
| --- | --- |
| 我不当王。 | Character leaves the crown/throne untouched and picks up a friend's object. |
| 我要改写命运。 | Character signs the wrong form, blocks the door, changes the route, or refuses an order. |
| 我要守护所有人。 | Character quietly takes the dangerous position in the formation. |
| 我不会让你被忘记。 | Character keeps a name written on a receipt / file / palm and protects it. |
| 我只是来赴约的。 | Character checks the time / meal card / old message and moves without explaining. |
| 这一次我自己选择。 | Character ignores the offered power and uses the weakest available tool. |

## Output Rule

In final prose, do not explain this technique. Just apply it. Let the scene carry grandeur; let dialogue remain human.
