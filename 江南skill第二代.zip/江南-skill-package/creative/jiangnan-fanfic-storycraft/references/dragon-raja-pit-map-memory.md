# Dragon Raja Pit Map & Foreshadowing Memory

> Source: user-provided DOCX pit map, reorganized for skill use. This file records unresolved mysteries, where they were planted, how the reboot material can patch them, and how to write payoffs without flattening the story into exposition.

## Global Rule

Do not solve Dragon Raja mysteries by directly assigning one neat label. The better mode is:

- show several institutions trying to label the mystery;
- let each label be partially useful and partially wrong;
- reveal the emotional cost before the technical answer;
- leave one layer of dread or ambiguity intact.

## 1. 路明非身份坑

### Planted / Old Slots

- Parents absent under vague “archaeology / major project” explanations.
- Cassell admission is obviously abnormal.
- S-level rating does not match early physical/academic performance.
- Can trade life with 路鸣泽.
- Reacts abnormally to top-level authority / emperor-like effects.
- Old speculation includes White King bloodline, Black King vessel, or higher-order existence.

### Reboot Patch Direction

- 路明非 is reinforced as a “strange thing” beyond ordinary mixed-blood categories.
- Parents' files being inaccessible/greyed strengthens the idea that his origin is institutionally blocked.
- Best handling: every taxonomy fails — mixed blood, White King blood, Black King vessel, key, anchor, container are all partial human attempts.

### Writing Rule

Do **not** write “路明非就是 X.” Write: the system keeps trying to classify him, and every result contradicts another result. His specialness should feel larger than the labels.

### Payoff Options

- Classifier scene: Norma / Gattuso / Cassell labels him differently and all are wrong in different ways.
- Object scene: his student file has correct details but impossible metadata.
- Emotional scene: Lu himself wants a normal answer and receives only a worse question.

## 2. 路鸣泽身份与交易机制坑

### Planted / Old Slots

- Why can he only act through deals?
- Why one-quarter life each time?
- Brother, demon, dragon, mirror, parasite, or something else?
- Why both tempter and protector?
- Why does he sound sad?

### Reboot Patch Direction

- Deals can be treated as world-line / permission / authority exchange, not simple demon barter.
- 路明非's life is not just currency; it may be his observer/anchor/key permission.
- 路鸣泽 can interfere with the world, but not freely; intervention has rules.

### Writing Rule

Keep the voice old-style: child prince, brother, salesman, demon. Do **not** make him explain like a physics professor.

### Payoff Options

- He explains one practical rule with a childish metaphor.
- His deal prevents one world-line collapse but worsens another personal loss.
- He refuses to answer “what are you,” but answers “what price do you want to pay.”

## 3. 黑王复活与诸神黄昏坑

### Planted / Old Slots

- Nidhogg / Black King return threatens world end, but early volumes leave it distant.
- Unknown whether Black King is dead, sleeping, rebuilding, or inevitable.
- Four monarch awakenings are not clearly tied to Black King return.
- “Ragnarök” works as mythic frame but needs plot mechanism.

### Reboot Patch Direction

- Black King return can be framed as a convergence /收束器-level event.
- Ragnarök becomes not legend but structural fate.
- Odin, Hyperborea, Godland, and apocalypse cult logic can connect to this line.

### Writing Rule

Use world-line/convergence sparingly. Keep the flavor mythic, alchemical, and tragic, not superhero multiverse jargon.

### Payoff Options

- Every faction's plan turns out to be a different way of surviving the same convergence.
- Black King is not merely “revived”; history is being forced to make room for his return.
- A local mission accidentally reveals it is one branch of the same final event.

## 4. 奥丁与楚天骄坑

### Planted / Old Slots

- Maybach rain night, 楚天骄, Odin, Gungnir, Nibelungen.
- Why did Odin pursue Chu Tianjiao?
- What is Chu Tianjiao's true status?
- Why is Chu Zihang erased?
- What exactly does Gungnir's fate-locking mean?

### Reboot Patch Direction

- Reboot expands Chu Tianjiao, Nono investigation, Odin, Godland, Yellow Dusk/Ragnarök frame.
- Odin line becomes world-level power, not just one monster in a rain scene.
- Gungnir should feel like causality/fate pressure rather than only a spear.

### Writing Rule

The old Odin line is powerful because it is frightening and not fully explainable. Explain enough to drive plot, but keep him partly beyond human memo-language.

### Payoff Options

- Investigation reveals what happened to records, not what Odin “is” in one sentence.
- Chu Tianjiao's clue helps save Chu Zihang but opens a worse Black King clue.
- Gungnir marks a choice as “already happened,” forcing characters to create a third route.

## 5. 白王与赫尔佐格坑

### Planted / Old Slots

- Japan arc raises White King, imperial blood, Erii as vessel/key, Herzog's usurpation.
- Did White King truly die?
- What is the relation between White King blood and Japanese “皇” blood?
- Was Herzog a real White King after usurpation?

### Reboot Patch Direction

- Herzog can be linked to extreme north, Hyperborea, Godland, and occult-scientific ideology.
- White King authority expands beyond “Oracle” into higher-order abilities / reports / usurpation language.
- Herzog is best treated as a usurper, not a true natural king.

### Writing Rule

He is not “the White King returned.” He is a human-built pseudo-king: technology, desire, stolen dragon blood, and religious-scientific madness.

### Payoff Options

- His leftover research misleads later factions because it worked just enough to be dangerous.
- Erii's tragedy remains emotional center; do not reduce her to “sample material.”
- White King authority should have aftershocks without undoing the Japan arc's cost.

## 6. 赫尔佐格前史与极北之地坑

### Planted / Old Slots

- Black Swan Harbor is strong but does not fully explain where Herzog's science/ideology came from.
- Bondarev / Herzog / Japan chain suggests larger origin.

### Reboot Patch Direction

- Extreme north / Hyperborea / Third Reich occultism / Godland gate / genetic deification gives him ideological ancestry.
- Black Swan Harbor becomes continuation of a failed old doctrine, not a random mad lab.

### Writing Rule

Use this as backstory pressure, not a new exposition dump. Herzog is a symptom of an era's disease: mysticism plus biology plus power fantasy.

### Payoff Options

- A document fragment links Black Swan terminology to Hyperborea terminology.
- A later antagonist repeats Herzog's mistake with better tools.
- A cold northern setting mirrors the cold lab where children were made into evidence.

## 7. 尼伯龙根计划坑

### Planted / Old Slots

- Gattuso family wanted it for Caesar.
- It can break mixed-blood limits, at great cost.
- It is never fully closed in older continuity.

### Reboot Patch Direction

- Can be associated with material extracted from Constantine's remains plus alchemical reagents.
- Rumor/interpretation that the chance may have gone to Lu Mingfei, not Caesar.
- Useful bridge from Volume I Norton line → Volume II plan → later Lu body/combat anomalies.

### Writing Rule

Do not make Lu special only because of a “dragon bone injection.” Better: the plan did not create his specialness; it activated, stabilized, or disguised something already wrong.

### Payoff Options

- Gattuso believes they built a weapon; later evidence says they merely disturbed a locked door.
- Caesar confronts the fact that a family plan meant for him was part of a larger plot.
- The plan explains symptoms, not origin.

## 8. 加图索家坑

### Planted / Old Slots

- Pompeii looks frivolous but knows too much.
- Frost appears powerful but may be an outer proxy.
- Passi is abnormal.
- Gattuso family pushes Nibelungen Plan.
- Caesar's mother, family blood, and long objective remain murky.

### Reboot Patch Direction

- Family strategic power can include hidden weapons, elder structures, inheritance halls, satellite/long-range force, marriage contracts.
- Nono/Caesar marriage becomes bloodline politics, not merely romance.

### Writing Rule

Gattuso is not only rich school politics. Treat them as a noble mixed-blood group building an apocalypse ticket inside the Secret Party.

### Payoff Options

- A family “rescue” is really a containment plan.
- Caesar's aristocratic freedom clashes with being packaged as heir/weapon.
- Nono is not marrying wealth; she is being absorbed by a survival machine.

## 9. 诺诺 / 陈墨瞳坑

### Planted / Old Slots

- Source of profiling ability.
- Why she first “sees” Lu Mingfei.
- Chen/Gattuso marriage mechanism.
- Her relation to Lu: salvation, guide, missed chance, or trap?
- Old Odin involvement unresolved.

### Reboot Patch Direction

- External situation: convent / Gattuso elder system / future matriarch inspection / formalized marriage documents.
- She can re-enter Odin line as investigator and participant.

### Writing Rule

Reboot can patch external shackles; old continuity should preserve internal regret. Nono is not Lu's reward or Caesar's property. She is a free person two worlds try to claim.

### Payoff Options

- She makes one decision neither Lu nor Caesar can make for her.
- Profiling ability reveals the emotional truth but not the whole supernatural truth.
- A marriage document becomes a mission object, not a romance answer.

## 10. 楚子航被世界遗忘坑

### Planted / Old Slots

- End of Odin arc: Chu is erased/replaced; only Lu remembers.
- Why only Lu?
- Is it Odin authority, world-line rewriting, replacement, death, or exile?
- “鹿芒” identity needs handling.

### Reboot Patch Direction

- Use world-line, fate stream, Nibelungen, Odin imprint, Nono investigation, Chu Tianjiao clues.
- Best interpretation: Odin did not simply make people forget; Chu was stripped from the legal history of this world-line.
- Lu remembers because he is not fully bound by the same line.

### Writing Rule

Proof should come from contradictions: wrong records, damaged memories, empty seats, false replacements, ordinary people hurt by the edit.

### Payoff Options

- Lu protects a name in a file because the world keeps correcting it.
- Nono reconstructs Chu through relational impossibilities.
- Recovery does not restore everything; some people keep the scar of the wrong history.

## 11. 龙王双生子与“王座”坑

### Planted / Old Slots

- Four monarchs / twin-seat system.
- Norton/Constantine mostly closed; Earth-and-Mountain via Xia Mi/Fenrir; Sky-and-Wind / Ocean-and-Water remain less complete.
- Is the throne biology, authority, memory, alchemy, or mythic structure?

### Reboot Patch Direction

- Use crown/rank/authority/report/final-form language as system, but avoid physical crown imagery in prose.
- Dragon king is not a single monster identity: life, authority, element, memory, dragon bone, and historical function form a seat.
- Twins are two necessary structures of one throne, not just siblings.

### Writing Rule

Do not show literal thrones unless canon scene demands it. Make “throne” appear through authority behavior: records change, elements obey, bone remains call, one twin's death fails to erase the seat.

### Payoff Options

- Killing one twin delays, distorts, or transfers the seat rather than deletes it.
- A false king can borrow authority but cannot complete the throne.
- Lu's identity mystery intersects with why some seats cannot classify him.

## 12. 神国 / 希柏里尔坑

### Planted / Old Slots

- Older continuity has Godland-like imagery, especially undersea divine burial places, but not a complete mainline.
- What is Godland: dragon ruin, human misreading, other civilization, genetic endpoint?
- Relation to Black King, White King, Odin?

### Reboot Patch Direction

- Extreme north, Hyperborea, Godland Gate, genetic deification, Black King remains, Ragnarök, Odin/Valhalla can unify this line.
- Godland may not be paradise; outside the gate may be hell.

### Writing Rule

Best unified handling: Godland is a name each faction gives to an endpoint it misunderstands. Dragon kings call it throne, humans call it Godland, Herzog calls it deification, Odin's line calls it Valhalla.

### Payoff Options

- Characters reach a gate and discover the gate reflects their ideology rather than a single truth.
- A faction's “heaven” is another faction's extinction machine.
- Hyperborea reveals why old myths, experiments, and modern blood politics are the same story in different languages.

## Pit Payoff Priority For Fanfic Endings

If writing a short ending, do not close all twelve. Pick **3–5 primary pits** and leave the rest as aftershocks.

Recommended clusters:

| Ending Type | Primary Pits |
| --- | --- |
| Chu Zihang/Odin ending | 4 奥丁楚天骄 + 10 楚子航遗忘 + 3 黑王收束 + 1 路明非例外性 |
| Lu Mingfei identity ending | 1 路明非身份 + 2 路鸣泽交易 + 7 尼伯龙根计划 + 3 黑王收束 |
| Japan/Erii aftershock ending | 5 白王赫尔佐格 + 6 极北前史 + 12 神国 + 9 诺诺自由 as contrast |
| Nono emotional completion | 9 诺诺 + 8 加图索 + 10 楚子航记忆 + 1 路明非身份 as background |
| Full endgame | 1 + 2 + 3 + 4 + 10 + 12, with 5/6/7/8/9/11 as supporting echoes |

## Payoff Style Checklist

- [ ] Does the payoff answer an emotional question before a lore question?
- [ ] Does every explanation create a cost or aftershock?
- [ ] Is 路明非 still awkward/human while handling the mystery?
- [ ] Are Nono / Chu / Caesar / Fingel active, not just witnesses?
- [ ] Is at least one ordinary object used as proof: file, ID, receipt, note, coordinate, phone, ticket?
- [ ] Are literal crowns/thrones avoided unless canonically necessary?
- [ ] Is the explanation partial enough to preserve dread?
