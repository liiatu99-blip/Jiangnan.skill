# Dragon Raja Continuity & Character-Fidelity Guide

> Scope: based on public summaries, official-platform blurbs, encyclopedia/character pages, and user feedback. Do not copy copyrighted passages. Use this to keep fanfic aligned with character function, setting logic, and Jiangnan-adjacent high-level craft without drifting into generic throne/chosen-one fantasy.

## Why the Previous Draft Drifted

Failure modes noticed by the user:

1. **Character drift**: 路明非 was made to speak and choose like a heroic fantasy protagonist, rather than a self-mocking, avoidant, emotionally hungry “衰小孩” whose courage appears through awkward action.
2. **Visible cross-work pollution**: adding crowns, thrones, church/armor, flags, and abstract “王” imagery made the scene feel like 九州 / 天之炽 cosplay rather than Dragon Raja.
3. **Middle-school dialogue**: lines like “我不当王” name the theme directly; Dragon Raja's better emotional beats usually make the character say something smaller or do something instead.
4. **Generic imagery**: rain/highway/clock/crown are not enough. The image must arise from the current arc's real setting: Shilan high school, Cassell, Beijing subway, Tokyo, red well, Arctic icebreaker, Nibelungen, official files, Norma, execution department, game/chat details, etc.

## Series Continuity Map

### I. 火之晨曦 — Entry / Lack / Being Seen

Core public premise: ordinary high-schooler 路明非 receives the Cassell College call and enters a hidden dragon world.

Character function:

- 路明非 begins as ignored, self-effacing, game-playing, emotionally underfed.
- The key wound is not “I must become strong” but “maybe someone finally cares that I exist.”
- Early “Jiangnan feeling” often comes from ordinary humiliation suddenly being interrupted by glamour and danger.

Use details: Shilan-style school memory, QQ/game/chat, interview, CC1000-like threshold, student ID, Norma, cafeteria, 3E, first mission.

### II. 悼亡者之瞳 — Mission / Companion Wound / Beijing Underground

Public summaries emphasize 楚子航, 夏弥, Beijing subway, 大地与山之王, and multi-perspective complexity.

Character function:

- 楚子航 is not a warm talker. His emotion appears as discipline, timing, and lonely persistence.
- 夏弥 is brightness and deception at once; her tragedy is that warmth and dragon nature are entangled.
- 路明非 is not central by swagger; he is often the one who witnesses and is pierced by someone else's wound.

Use details: subway, station lights, files, six-flags/mission energy, old rain-night trauma, key/household object, underground collapse.

### III. 黑月之潮 — Tokyo / Guest Ensemble / Tragic Tenderness

Public summaries emphasize Japan sea, Japan branch betrayal, 高天原, 源氏/蛇岐八家 politics, 源稚生/源稚女/绘梨衣 tragedy.

Character function:

- 路明非 becomes emotionally memorable by trying to give 绘梨衣 ordinary freedom, not by declaring epic purpose.
- 绘梨衣's power is terrifying, but her emotional vocabulary is small, written, childlike, concrete.
- 源氏兄弟 tragedy works because huge violence is tied to childhood memory and family misrecognition.

Use details: hotel, street, game center, red well, sea, black cars, Japanese branch files, handwritten notes, small trips, brother/sister family debt.

### IV. 奥丁之渊 — Erasure / Search / Cause and Effect

Public materials emphasize 楚子航's disappearance/erasure, 奥丁, Nibelungen-like spaces, and 路明非 holding onto a missing person's existence.

Character function:

- 路明非 should not become a chosen king. He is the person who stubbornly refuses the world's edited version because it feels wrong.
- The emotional center is evidence: records, photos, school memories, contradictions, habits, empty seats, someone else's place in the world.
- 奥丁/fate is best felt as edits to reality, not as someone giving a lecture on destiny.

Use details: missing records, false replacement, Shilan memories, rain-night traffic, highway, files that don't match lived memory, Nibelungen thresholds.

### V. 悼亡者的归来 / 龙王：世界的重启 — Reassembly / Arctic / Ancient Gate

Official-platform blurbs and public snippets for 《龙王：世界的重启》 emphasize: forgotten/extreme north, Hyperborea-like lost place, a gate toward “神国,” ancient civilization secrets, harsh choices before a gate, and the young people's growth/war. Public search snippets also mention Arctic / icebreaker imagery and reworked continuity after Japan.

Character function:

- Endgame is not “路明非 ascends.” It is old mysteries pressing on a boy who still thinks in awkward, concrete, human terms.
- The Arctic / ancient-gate mode should feel cold, technical, navigational, and exploratory — coordinates, ice, ship lights, old civilization traces — not medieval throne fantasy.
- If using 楚子航/夏弥 material from reboot discussions, keep it restrained: body change, sleeping presence, partnership/haunting, not melodramatic speeches.

Use details: Arctic sea, icebreaker, navigation reports, lost northern civilization, gate, old experiments, erased/rewritten continuity, mission logs, cold machinery.

## Character-Fidelity Rules

### 路明非

Do:

- Keep him awkward, avoidant, self-mocking, observant, and emotionally hungry.
- Let courage appear as reluctant action after a small, human trigger.
- He may joke, but the joke should often fail to hide hurt.
- His thoughts can be mundane at catastrophic moments: computer game, cafeteria, old crush, uncle/aunt home life, being seen by someone.
- Show him choosing by doing a small wrong-looking thing: protecting a file, refusing to delete a name, stepping into a station, holding onto a note.

Don't:

- Make him solemnly declare “I reject kingship / destiny / the ending.”
- Make him suddenly possess polished heroic certainty.
- Make him speak like an epic-war protagonist or philosophical narrator.
- Overuse “废柴” comedy once the scene is serious; he becomes quieter, not louder.

### 楚子航

Do:

- Keep speech minimal, factual, tactical.
- Emotion appears as punctuality, preparation, remembering details, blocking danger, not verbal confession.
- His loneliness and father wound should be quiet pressure.
- In action, he moves cleanly; in emotion, he often fails to name it.

Don't:

- Give him sentimental speeches.
- Make him call out abstract ideas like fate/king/world unless quoting a mission term.
- Make him over-explain his motives.

### 诺诺 / 陈墨瞳

Do:

- Keep her sharp, perceptive, side-reading people, and outwardly casual.
- Her lines can sting, but should be economical.
- She acts before comforting; rescue and provocation are both care.
- Her loneliness is hidden under motion and confidence.

Don't:

- Reduce her to “活着回来” or generic worried heroine.
- Make her only a mission dispatcher.
- Overuse cute banter; one precise cut is stronger.

### 恺撒

Do:

- Keep pride, aristocratic ease, generosity, and self-dramatizing elegance.
- He can sound grander than others, but it should be stylish and socially aware, not childish.
- His choice often pits family/order against self-defined honor.

Don't:

- Turn him into generic bossy rich boy or empty rival.

### 芬格尔

Do:

- Use comedy as camouflage for competence and old knowledge.
- He can undercut tension, but should not destroy scene gravity.
- His jokes should often hide that he understands more than he admits.

Don't:

- Let him spam meme lines in climaxes.

### 绘梨衣

Do:

- Keep language small, written/gesture-based, concrete.
- Pair terrifying power with childlike attention to ordinary happiness.
- Her tragedy is strongest when she names simple things, not when others over-poeticize her.

Don't:

- Make her deliver adult philosophical speeches.

### 路鸣泽

Do:

- Elegant, precise, dangerous, intimate.
- Sounds like a child prince, salesman, brother, and demon at once.
- Offers deals; rarely wastes words.

Don't:

- Make him a generic villain explaining plot.

## Dragon Raja Imagery Rules

### Real Dragon Raja image families

Use setting-native images:

- school / youth: classroom, literary club, projector, QQ window, game screen, exam paper, cafeteria, dorm corridor;
- Cassell: Norma, student ID, execution department files, black helicopter, library, 3E, professor, briefing room;
- urban mission: subway, station broadcast, overpass, toll booth, hotel corridor, amusement park, black car, rain on windshield;
- Japan arc: hotel room, game console, handwritten labels, red well, sea, shrine/street, branch politics, black suits;
- Odin arc: impossible rain-road, edited records, false memory, missing photo, highway/Nibelungen threshold;
- reboot/endgame: Arctic, icebreaker, navigation coordinates, frozen sea, ancient gate, lost civilization, mission log.

### Avoid fake grandeur unless canon context earns it

Avoid visible generic fantasy items unless specifically justified:

- crown, throne, kingly table, medieval banners, random church, giant mecha, nameless empire, ceremonial oath.

These can be structural influences from other works, but should not appear as surface images in a Dragon Raja scene unless the requested plot specifically includes them.

### Better image logic

Instead of “王冠 on table,” use:

- a file whose name keeps changing;
- a student ID that fails to scan;
- a mission form with a blank line where someone should be;
- a phone contact that cannot be deleted;
- an Arctic coordinate printed on wet paper;
- a cafeteria receipt with a name on the back;
- a train ticket to an impossible station.

## Revised Dialogue Rules

- Dialogue should be less than the scene wants to say.
- Characters should not know the theme title.
- Avoid “王/命运/结局/守护/救赎” in declarations.
- Let route choices, files, small objects, and refusal to cooperate with edited reality express the theme.
- If a line sounds cool in isolation, it is probably wrong.
- If a line sounds almost too ordinary for the apocalypse, it may be right.

## Scene Preflight Checklist

Before writing canon-character fanfic:

1. Which continuity moment? I / II / III / IV / V / Reboot.
2. Who is emotionally central? 路明非, 楚子航, 诺诺, 恺撒, 绘梨衣, 路鸣泽, or ensemble?
3. What is the small human object? ID, file, meal card, note, game screen, ticket, phone, photo, coordinate.
4. What is the real setting family? school, Cassell, subway, Tokyo, highway, Arctic.
5. What exact record/memory is wrong?
6. What action, not speech, proves the character's choice?
7. Delete all poster lines before final output.
