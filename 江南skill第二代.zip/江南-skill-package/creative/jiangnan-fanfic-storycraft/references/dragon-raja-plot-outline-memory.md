# Dragon Raja Plot Outline Memory

> Source: user-provided DOCX synthesis files, reorganized for skill use. This is high-level plotting memory and public-material analysis, not quoted source text. Use it to keep continuations aware of the existing story architecture, chapter functions, rhythm, and where major setup/payoff sits.

## How To Use This Reference

Before writing any ending, IF line, long outline, or chapter continuation:

1. Pick the continuity stage: I / II / III / IV-old / V-Reboot.
2. Identify the external mission and the internal wound.
3. Check which existing pit/foreshadowing the scene touches.
4. Do not explain every mystery at once; Dragon Raja tension depends on partial knowledge and emotional payoff.
5. Use confirmed-public information as anchor; mark speculative connective tissue as fanfic design.

## Volume I — 《火之晨曦》

### Core Position

- **External line:** ordinary high-schooler 路明非 receives Cassell College's call and enters the dragon-war world.
- **Internal line:** a neglected, low-self-worth boy is suddenly seen, chosen, and forced to decide whether someone is worth paying for.
- **Deep function:** entry volume. It sells hidden-world wonder with school comedy, then reveals that every miracle has a price.

### Structural Outline

| Segment | Surface Event | Writing Function |
| --- | --- | --- |
| Mythic prologue | White Emperor City / dragon-brother imagery | Establish dragons as tragic kin, not pure monsters. |
| Low daily life | Shilan school, foster-family awkwardness, 陈雯雯 crush | Build 路明非 as emotionally underfed and invisible. |
| Summons | Cassell offer, Nono intervention, dragon-world reveal | Turn humiliation into invitation; fantasy breaks daily failure. |
| Academy spectacle | Cassell, freedom day, S-level controversy, Caesar/Chu contrast | Build the cool institutional shell and strength ladder. |
| First real mission | Three Gorges / bronze city / Norton clues | Shift from campus fun to death, duty, and world crisis. |
| Emotional pressure | Nono closeness, loneliness, private motive | Make later rescue personal rather than abstract heroism. |
| Dragon mirror | Norton/Constantine brother tragedy | Complicate “slay the monster”; enemy also has love and loss. |
| Costly climax | Seven Deadly Sins, Lu Mingze deal, rescue | Establish power-for-life mechanism. |
| Hook ending | parents, Lu Mingze, Nono, dragon war unresolved | Give a win but keep the bigger machinery hidden. |

### Key Character Arcs

- **路明非:** from “nobody cares if I exist” to “I will pay a price for one person.” Do not make him triumphant; the win is mixed with dependency on 路鸣泽.
- **诺诺:** summoner / rescuer / existence-confirming figure, but not a reward. She is the door, not the possession.
- **恺撒 / 楚子航:** two aspirational male templates — aristocratic leader vs. disciplined blade.
- **芬格尔:** comic information broker with concealed competence.
- **老唐 / 诺顿 / 康斯坦丁:** dragon-side brother tragedy mirrors human-side brother/contract mystery.

### Setup / Foreshadowing Slots

- White Emperor City and brother imagery → dragon kings as tragic family structure.
- S-level but apparently useless 路明非 → abnormal identity and later contract/authority puzzles.
- 路鸣泽 contract → power must cost life/permission/authority.
- Nono's rescue/seeing of 路明非 → long emotional debt, not simple romance.
- Parents absent and secretive → main identity mystery and institutional manipulation.
- Seven Deadly Sins → weapon system and myth/alchemy layer.

## Volume II — 《悼亡者之瞳》

### Core Position

- **External line:** Earth-and-Mountain King crisis, from mission threads to Beijing subway Nibelungen.
- **Internal line:** 楚子航's father wound, bloodline instability, and love/kill tragedy with 夏弥.
- **Deep function:** shifts the series from single protagonist entrance to multi-perspective tragedy. The real question is not whether they can kill a dragon king, but whether a boy can swing the blade when the enemy has a beloved human face.

### Structural Outline

| Segment | Surface Event | Writing Function |
| --- | --- | --- |
| Rain-night wound | 楚子航, 楚天骄, Maybach, Odin, Nibelungen | Put grief and incomprehensible fear at the front. |
| Birthday/task collision | 路明非 birthday and Cassell mission | Pollute youth ritual with death and duty. |
| Chu as hidden center | missions, bounty, dangerous competence | Reframe focus toward Chu's internal danger. |
| Xia Mi enters | lively junior sister, Nibelungen Plan nearby | Laugh while planting the bomb. |
| Seven Deadly Sins auction | weapons, capital, politics | Dragon war becomes expensive, ancient, political. |
| Amusement park disaster | date-like scene becomes catastrophe | Push Chu into burst-blood exposure and later trial. |
| Trial / institution pressure | school board, blood samples, Night Watcher | The organization is also an antagonist. |
| Beijing subway maze | Dragon Bone Cross, blood pact, labyrinth | Turn a real city into mythic underground. |
| Identity reversal | Xia Mi = Jörmungandr | The most human warmth becomes the dragon king. |
| Tragic resolution | collapse, dragon king death, loss | Victory equals mourning. |

### Key Character Arcs

- **楚子航:** disciplined blade forced to face father-loss, bloodline danger, and love as enemy. Emotion appears through action, memory, timing, not speeches.
- **夏弥 / 耶梦加得:** comic warmth and dragon nature are the same person. The tragedy works only if she was convincingly alive before the reveal.
- **路明非:** central but partly displaced; his protagonist function is to witness, pay, and be wounded by others' tragedies.
- **芬里厄:** childlike dragon king; reinforces that dragons are also lonely / dependent.
- **昂热 / 校董会:** institutional pressure and hidden political costs.

### Setup / Foreshadowing Slots

- Odin / rain road / Chu Tianjiao disappearance → long Odin line and reality rewriting.
- Burst blood and Chu's unstable golden eyes → trial, bloodline crisis, later identity vulnerability.
- Xia Mi's excessive fit with Nibelungen and Chu line → later Jörmungandr reveal.
- Seven Deadly Sins → weapon payoff and symbolic inheritance from Volume I.
- Nibelungen Plan → Gattuso / Caesar / later Lu Mingfei physical upgrade questions.
- “Everyone has a dead child in heart” thematic tail → future writing should keep adult competence haunted by buried youth.

## Volume III — 《黑月之潮》

### Core Position

- **External line:** Japan mission, White King resurrection crisis, Snake family politics, Tokyo endgame.
- **Internal line:** 路明非 receives a brief private fairy tale with 绘梨衣 and fails to save it.
- **Deep function:** expands the series into international tragedy: spy mission + yakuza politics + Cold-War experiment horror + myth reconstruction + brother tragedy + love tragedy.

### Structural Outline

| Segment | Surface Event | Writing Function |
| --- | --- | --- |
| Black Swan prologue | Siberian experiments, Herzog/Bondarev/Zero/Renata | Seed White King, human experimentation, and old evil. |
| Japan task | Cassell trio, dive mission, sea trench / Takamagahara | Expand scale beyond school and China. |
| Betrayal / escape | Japan branch turns, trio hunted | Convert mission film into fugitive film. |
| Takamagahara comedy | host-club absurdity, trio brotherhood | Release pressure and make the trio human again. |
| Source Heavy Industries | murals, White King blood, Snake family secrets | Reveal local myth/history/power structure. |
| Tokyo fairy tale | 路明非 and 绘梨衣 small freedom | Give him a near-private world before destroying it. |
| Source brothers | 稚生 / 稚女 conflict | Humanize “king/blood” through family misrecognition. |
| Red Well / White King | Herzog plot, Erii as vessel | Turn world plot into private loss. |
| Third deal / sky battle | Lu Mingze transaction, apocalypse response | Heroism costs another part of the self. |
| Aftertaste | Tokyo scar, unresolved contracts | Private mourning outweighs mission success. |

### Key Character Arcs

- **路明非:** from reluctant participant to someone who actively tries to steal a girl from fate; the tragedy is that wanting to save her is not enough.
- **绘梨衣:** terrifying power + small language + ordinary wishes. She should express through notes, labels, gestures, simple objects, not speeches.
- **源稚生:** “responsibility as prison”; a supposed emperor who cannot live an ordinary life.
- **源稚女 / 风间琉璃:** brother's dark mirror; reconciliation wish collapses into duel.
- **赫尔佐格 / 王将:** not a true god, but a human trying to become one through technology, manipulation, and stolen authority.
- **恺撒 / 楚子航:** action/brotherhood/comedy support in Japan, but do not erase their independent agency.

### Setup / Foreshadowing Slots

- Black Swan Harbor → Herzog, Zero, White King experiment, later extreme-north thought lineage.
- Greenland / sea trench old wound → academy's old casualties and dragon-city horror.
- Japan branch courtesy → betrayal.
- “皇” bloodline → Source siblings / Erii / White King system.
- Erii as weapon/key → White King vessel tragedy.
- Tokyo Love Story plan → manipulated romance that still becomes emotionally real.
- Source brothers' reconciliation wish → doomed duel.
- Repeated Lu Mingze deals → every heroic transformation means less intact humanity.

## 《龙王：世界的重启》 / Reboot Direction

### Core Position

- **External line:** 楚子航 is erased from world memory; 路明非, 诺诺, 芬格尔 search world-line loopholes; Odin/Nibelungen/0号高速 reappear; γ-line loops and extreme-north mysteries reshape the endgame.
- **Internal line:** 路明非 changes from the boy rescued by Nono into the exhausted young executor who repeatedly fails, remembers, and still tries to bring people through the flood.
- **Deep function:** transition volume. It moves the series from mission-adventure to world-line repair, and from youth wound to adult return-to-youth reckoning.

### Structural Outline

| Segment | Chapters / Arc | Writing Function |
| --- | --- | --- |
| Arctic cold start | 北极之墟, YAMAL, Hyperborea / Gate | Start at endgame scale: cold, technical, ancient, exploratory. |
| Lu's adult status | 零号病人, execution tasks | Show 路明非 as tired, operational, dangerous, no longer pure “衰仔”. |
| Old youth summoned | Nono, classmates, China return | Bring emotional debts back before Odin war. |
| Core abnormality | Chu erased, world records wrong, 0号高速 | “Find Chu” becomes “the world has been edited.” |
| γ-line loops | repeated failed reads / resets | Make failure structural and cumulative. |
| Father-generation truth | 楚天骄 base, red-line event net | Tie Chu disappearance to Nidhogg / endgame. |
| Real-world support | 苏晓嫱, 柳淼淼, 苏小妍, mental hospital | Let old classmates become adult-world resources. |
| No retreat | fugitive, mirror/Nibelungen, Odin challenge | Lu acts with accumulated failed knowledge, not clean heroic certainty. |
| Tail hook | 芬格尔, 酒德麻衣, 村雨 black flame | Reveal hidden lines and keep next volume open. |

### Key Character Arcs

- **路明非:** from rescued boy to rescuer/anchor, but still awkward and concrete. He should be tired, afraid, and practical, not a radiant king.
- **诺诺:** external family/marriage constraints plus internal unresolved freedom. She participates in inference and action; she is not a passive beloved.
- **楚子航:** absent center. His lack reshapes everyone else. He is proven by contradictions, records, habits, and the people damaged by his erasure.
- **楚天骄:** father-generation watcher; turns a family wound into endgame conspiracy.
- **路鸣泽:** still demon-brother voice, but can function as world-line/permission explainer. Keep him elegant, intimate, and dangerous; do not turn him into a classroom lecturer.
- **芬格尔:** comic shell with dangerous hidden history; tail-hook character.
- **苏晓嫱:** adult echo of school days; old ordinary world can still rescue the protagonist.

### Setup / Foreshadowing Slots

- Hyperborea / extreme north / Gate → long-term civilization and “godland is maybe hell” mystery.
- Chu erased → motivates investigation and proves reality edit, not simple amnesia.
- Su Xiaoyan mental hospital damage → world-line changes harm ordinary people.
- 0号高速 / Maybach / rain → pay back Volume II Odin trauma.
- γ-line loop counts → show repetition, exhaustion, and acquired competence.
- Chu Tianjiao's red-line web → converge scattered dragon events toward Nidhogg.
- Nono relationship rewrites → turn teenage crush into adult protection / letting go.
- Fingel with Muramasa black flame → future hidden combat/history line.

## Cross-Volume Design Patterns To Preserve

1. **High myth → low daily life:** start with dragon/war/history, then cut to cafeteria, school, game, file, or awkward human habit.
2. **Victory is contaminated:** slaying a dragon, solving a mission, or saving one person usually costs love, memory, life, or innocence.
3. **The enemy is mirrored family:** Norton/Constantine, Xia Mi/Fenrir, Source brothers, Lu/Lu Mingze, Chu/Chu Tianjiao.
4. **Power must be paid for:** transactions, bloodline breakthroughs, weapons, and world-line edits must cost something visible.
5. **The scene's object carries the emotion:** receipt, ID card, file, game screen, note, coordinate, broken pen, student record.
6. **Do not over-close mysteries:** explanations should deepen dread, not flatten it into wiki exposition.

## Quick Use Matrix

| User wants | Use this memory |
| --- | --- |
| “龙族结局” | Reboot stage + pit map: black king / Odin / Chu erasure / Lu identity. |
| “楚子航线” | Volume II wound + Reboot erasure + Chu Tianjiao pit. |
| “路绘补完” | Volume III Tokyo fairy tale + Erii small-language rule. |
| “诺诺线” | Volume I summoner role + Reboot marriage/freedom constraints. |
| “芬格尔隐藏线” | Reboot tail hook + Black Swan/old-knowledge suspicion. |
| “补设定” | Always consult pit-map memory; avoid direct single-label answers. |
