# Jiangnan Cross-Works Public-Source Craft Analysis

> Scope: this reference is based on public summaries, encyclopedia entries, official-platform blurbs, and high-level reader/critic commentary about Jiangnan's works. It is **not** a corpus and must not be used to copy or reconstruct copyrighted text. Use it to guide high-level craft choices for non-commercial fanfic / reader-emotional-completion work, while avoiding exact imitation of a living author's distinctive phrasing.

## Works Considered

### 《此间的少年》 Mode: Campus Nostalgia / Wuxia Shell, Youth Core

Public summaries describe it as a university-life story set around “汴京大学,” modeled on Peking University, with familiar wuxia-character archetypes placed into modern campus life.

High-level craft uses:

- **Low-stakes surface, high-aftertaste emotion**: meals, classes, dorms, exams, basketball, small jealousies and farewells carry more feeling than the plot appears to contain.
- **Parodic shell, sincere core**: famous archetypes can be made ordinary, but the emotional truth is not parody. People laugh, waste time, miss chances, and later remember them as youth.
- **Youth memory texture**: the narrator often seems to know that these days will not return. Write the scene as if it is happening now, but with a faint future regret under it.
- **Small-object closure**: a meal card, library seat, dorm light, bicycle, old note, instant noodles, or a half-finished joke can carry the ending.

Use when a Dragon-Raja fanfic needs warmth, campus comedy, ordinary friendship, or a “before everything became fate” contrast.

### 《九州缥缈录》 Mode: Historical Epic / Young Kings Before History

Public summaries describe it as a six-volume fantasy epic set in the Novoland world, weaving Northland nomadic tribes and Eastland dynastic conflict, with future generals and emperors in their youth. Some encyclopedia descriptions note multi-line narration, flashbacks/interludes, and a more solemn historical tone.

High-level craft uses:

- **History presses on youth**: characters may be teenagers, but the narrative treats them as people who will one day become names in chronicles.
- **War and politics as weather**: alliances, banners, cavalry, gates, cities, royal courts, tribal oaths, religious forces, and old secret orders should feel larger than any one person.
- **Epic camera movement**: move from vast battlefield / grassland / imperial city to one boy's hand, one horse's breath, one blade, one promise.
- **Friendship under history**: the strongest sadness comes when private friendship is crushed or rerouted by public destiny.
- **Solemn cadence**: fewer jokes, more ritual weight; oaths, titles, flags, bloodlines, and departures matter.

Use when a Dragon-Raja ending needs “final war,” “old order collapsing,” “young people becoming legends,” or “friendship scattered by history.”

### 《龙族》 Mode: Urban Myth / Youth Self-Mockery Under Apocalypse

Public summaries emphasize an ordinary high-schooler entering Cassell College, a hidden dragon-slaying world, modern missions, dragon kings, memory/identity mysteries, and large cinematic set pieces.

High-level craft uses:

- **Modern object + mythic pressure**: subway, high-speed road, school cafeteria, phone, hotel, convenience store, and black car coexist with dragon bone, kingship, bloodline, alchemy, and Nibelungen-like spaces.
- **Self-mockery under fate**: the protagonist's embarrassment and cowardice should not be erased; courage means acting while still seeing oneself as ridiculous.
- **Memory/identity wound**: someone is forgotten, misremembered, replaced, or not what they seem. The plot answer must be emotionally costly.
- **Cinematic action**: rain, neon, glass, metal, speed, recoil, wind pressure, and impossible spatial shifts produce memorable set pieces.

Use for core Dragon-Raja fanfic continuation.

### 《天之炽》 Mode: Mechanical Gothic / Family Protection in Power Struggle

Public summaries describe a large fantasy story after Dragon Raja, involving mixed-blood youth Cesare Borgia, papal-state power struggle, protection of family/sister, steam machinery, and Seraph-like mecha.

High-level craft uses:

- **Machine + church + bloodline**: cathedral light, iron, steam, armor, engines, gears, holy titles, and political cruelty create a colder, more metallic atmosphere.
- **Protective motive**: the hero may be isolated or dangerous, but his central desire can be small and domestic — protect a sister, family, or fragile private life.
- **Power as machinery**: politics should feel like an engine that keeps turning even when people are crushed inside it.
- **Combat as engineering**: write machinery weight, hydraulic force, armor joints, heat, oil, pressure, metal fatigue, and the pilot's body cost.

Use when a Dragon-Raja fanfic wants a more mechanical, religious, imperial, or weapon-system-heavy final arc.

### 《上海堡垒》 Mode: City-Scale War / Unspoken Love Under Disaster

Public summaries and broader commentary place it among Jiangnan's science-fiction / romance works: city defense, alien-war pressure, and private emotion under public catastrophe.

High-level craft uses:

- **City as emotional container**: the city is not background; its lights, roads, shelters, towers, and skyline hold the characters' private regrets.
- **Love spoken too late or not at all**: the emotional engine is often a missed confession, a duty that interrupts tenderness, or a farewell hidden inside ordinary words.
- **Large disaster, small heart**: war is huge, but the memorable beat is often a person looking at a phone, a message, a window, or a street they may never see again.

Use when the fanfic ending needs city-defense scale or quiet romantic regret.

## Cross-Works Craft DNA

### 1. The “Small Promise Under Huge Fate” Pattern

A character may stand before empire, dragon, church, alien fleet, or history — but the emotional reason to move is small:

- return for a meal;
- protect a younger sibling;
- remember a forgotten friend;
- keep an old promise;
- sit once more in a campus seat;
- go home before dawn;
- say a sentence that youth never dared say.

The smaller the promise, the more credible the epic becomes.

### 2. The “Low Sentence / High Sentence” Alternation

A paragraph often gains power by letting ordinary language and elevated language coexist:

- low: a joke, a practical object, a cheap meal, a bad exam, a phone battery, wet socks;
- high: king, history, dragon, oath, empire, bloodline, battlefield, church bell, world ending.

Do not write only grand declarations. Do not write only jokes. Let the low sentence undercut the high sentence, then let the high sentence return with more weight.

### 3. The “Future Chronicle Shadow”

Even when writing close third-person, the narration can carry a faint sense that someone is remembering this later. This is especially useful for epic / tragic scenes:

- a scene feels ordinary now, but the narration knows it will become unrecoverable;
- a casual joke becomes the last ordinary sentence before history begins;
- a character is still young, but the world is already preparing a title, wound, or legend for them.

Use sparingly. Too much future-commentary becomes melodrama.

### 4. The “Object as Emotional Anchor”

Never let emotion float as pure abstraction. Anchor it in an object:

- campus mode: meal card, dorm light, textbook, bicycle, cafeteria bowl;
- epic mode: banner, horse sweat, old sword, blood-stained cloak, city gate;
- urban myth mode: phone screen, subway card, black car, raincoat, bullet casing;
- mechanical gothic mode: gear oil, pilot glove, cathedral glass, armor joint;
- city-war mode: skyline, shelter broadcast, unopened message, streetlamp.

### 5. Paragraph Music

For Jiangnan-adjacent high-level fiction, paragraph rhythm should feel composed:

- 2–5 sentences per paragraph by default;
- start with an image or physical fact;
- bend toward character emotion;
- end with movement, contrast, or a sentence that changes the pressure;
- use one-line paragraphs rarely, like cymbal crashes.

A good paragraph is neither “short-video punchline” nor “dense literary wall.”

### 6. Battle / Action Across Modes

- Campus mode: action is usually comic or human-scale; use it to show character relation.
- Epic mode: battle is about formations, banners, gates, horses, command decisions, morale, and irreversible losses.
- Urban myth mode: battle is cinematic and impossible; glass, rain, vehicles, neon, alchemy, and body recoil matter.
- Mechanical gothic mode: battle is engineered; weight, pressure, heat, armor, steam, oil, hydraulics, and pilot cost matter.
- City-war mode: battle is disaster management; sirens, broadcasts, collapsing districts, military command, and private farewell matter.

Each battle must change the story state: a position lost, a promise broken, a secret revealed, a character wounded, a city altered, or a choice forced.

## Application Mixer for Dragon-Raja Fanfic

When writing a Dragon-Raja ending, mix the modes deliberately:

- **Core**: 45% Dragon Raja urban myth — modern city + dragon/fate + memory/identity.
- **Warmth**: 15% 此间 campus nostalgia — jokes, youth, ordinary objects, missed chances.
- **Scale**: 20% 九州 epic chronicle — history, banners, old orders, final war, titles and destiny.
- **Texture**: 10% 天之炽 mechanical gothic — machines, metal, church/ritual, engineered weapons.
- **Aftertaste**: 10% 上海堡垒 city-war romance — city-scale disaster + unsaid tenderness.

Adjust per user request. For a pure Dragon Raja scene, reduce other modes but keep their functions: warmth, scale, texture, aftertaste.

## Guardrails

- Do not copy passages, chapter titles, signature lines, or highly recognizable phrasings.
- Do not claim the output is Jiangnan's writing or official continuation.
- Do not overfit to visible motifs like “rain/highway/senior brother” only; the deeper pattern is small promise vs huge fate.
- If the user asks for “more like Jiangnan,” translate that into craft knobs: more campus warmth, more epic chronicle, more urban myth, more mechanical texture, more restrained aftertaste.
