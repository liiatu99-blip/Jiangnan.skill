# Dragon Raja Public-Source Craft Analysis

> Scope: based on public summaries, encyclopedic entries, official-platform snippets, search-result descriptions, and user feedback. Do **not** scrape or paste copyrighted full text into prompts. This note extracts high-level craft patterns for non-commercial fanfic / reader-emotional-completion work; it is not a corpus and not a license to copy passages.

## Source Notes Consulted

- Wikipedia / public encyclopedia data: 《龙族》 began serializing in 2009; single-volume publications include 《龙族Ⅰ 火之晨曦》, 《龙族Ⅱ 悼亡者之瞳》, 《龙族Ⅲ 黑月之潮》上/中/下, 《龙族Ⅳ 奥丁之渊》; 《龙族Ⅴ 悼亡者的归来》 began online serialization in 2018.
- Public summaries describe the premise: ordinary high-schooler 路明非 receives the Cassell College call, enters a hidden dragon-slaying world, and faces identity, love, and choice under mythic pressure.
- Public summaries for later volumes emphasize: mission arcs, Chicago / Beijing subway / dragon king awakening in volume II; Japan-sea and Japan-branch arcs with large ensemble tragedy in volume III; 楚子航, 奥丁, 世界遗忘, 尼伯龙根 / high-way imagery in volume IV; volume V / 《龙王：世界的重启》 as unfinished / reworked continuation material on official platforms.
- Reader commentary repeatedly notices: rain, highways, Nibelungen-like liminal spaces, cinematic set pieces, youth banter against huge fate, and emotionally memorable supporting-character arcs.

## Series Map for Fanfic Planning

### Volume I Mode: Door-Opening Youth Fantasy

Function: ordinary life is punctured by a secret institution. The protagonist starts as a self-deprecating ordinary boy, not a chosen heroic figure in his own mind. The story energy comes from campus comedy, bewilderment, mystery entrance, and first contact with the violent hidden world.

Use for fanfic when: introducing a new reader-friendly branch, rebuilding the protagonist's emotional baseline, or writing a “return to beginning” ending.

### Volume II Mode: Mission + Personal Wound

Function: the mission structure becomes clearer. A public / modern setting hides an ancient dragon crisis. The volume's emotional center is not just the target but the personal wound of a key companion. The set piece is usually urban, kinetic, and rule-driven.

Use for fanfic when: a companion's forgotten debt must be confronted through an urban mission.

### Volume III Mode: Foreign City Tragedy / Ensemble Opera

Function: the story moves into an unfamiliar territory with its own internal politics, family debts, masks, twins / mirrors, and doomed tenderness. The tragic power comes from a guest ensemble that becomes emotionally central, then is broken by history and ambition.

Use for fanfic when: creating a major arc around a city, branch family, or local mythology; especially when romance and violence are inseparable.

### Volume IV Mode: Memory Erasure / Search for the Missing

Function: a person is erased from the world, leaving only emotional residue and contradictions. The protagonist's task is to insist that the missing person existed. Rain, highway, impossible vehicle imagery, and Nibelungen-like liminal space become the emotional architecture.

Use for fanfic when: writing about remembrance, absence, refusal to forget, or rescuing someone from erased history.

### Volume V / Reboot Mode: Endgame Reassembly

Function: old mysteries and unfinished arcs are pulled back together: identity, parentage, dragon kings, old experiments, secret histories, and the protagonist's final relation to monstrosity / kingship. Fanfic here should prioritize coherent closure over adding more lore.

Use for fanfic when: designing endings, resolving identities, giving each major character a final choice, or choosing what the protagonist refuses to become.

## Core Narrative Engine

A Dragon-Raja-like arc usually runs on three simultaneous engines:

1. **Mission engine**: a concrete objective with countdown and geography — enter the subway, cross the bridge, find the missing person, stop the gate, retrieve the name, prevent awakening.
2. **Memory / identity engine**: someone is not what they seem, or the world remembers them incorrectly. The plot answer must hurt a character personally.
3. **Youth emotional engine**: beneath dragons and kings is a small promise — bring someone home, remember someone, repay a meal, go to the beach, finish a date, keep a seat.

If any engine is missing, the result feels hollow: pure lore becomes encyclopedia; pure dialogue becomes sitcom; pure battle becomes game script.

## Paragraph Rhythm Model

Previous test outputs failed in two directions: too fragmented, then too block-heavy. Use **medium cinematic paragraphs**, not one-line staccato and not wall-of-text.

Recommended default for Chinese prose:

- Normal paragraph: **2–5 sentences**, roughly **90–220 Chinese characters**.
- Atmosphere paragraph: up to **260–320 characters** only when opening a scene or holding an emotional turn.
- Action paragraph: **60–160 characters**, because motion needs readability.
- Impact line: **1 sentence / 10–40 characters**, used rarely for reveal, silence, death, decision, or final echo.
- For a 1000–1500 Chinese-character sample: aim for **8–14 paragraphs**, with only **2–4 very short impact paragraphs**.

Paragraph should usually combine:

1. camera / scene detail;
2. one emotional inference;
3. one plot movement;
4. optional compressed dialogue or action.

Do **not** let every dialogue line become a separate paragraph unless the scene is intentionally sparse.

## Dialogue Ratio

Dialogue should be sharp but not dominant.

- In a 1000-character scene, use about **4–8 dialogue lines**.
- Each line should either reveal relationship, hide pain, reverse expectation, or complete a callback.
- Avoid chatty back-and-forth. Put narration between dialogue lines: hand motion, rain shift, weapon weight, city noise, someone not looking at someone else.
- The narrator should carry atmosphere and implication; characters should not explain everything aloud.

## Prose Texture: High-Level Emulation, Not Exact Imitation

Key texture knobs:

- **Modern + mythic collision**: cafeteria card beside dragon bone; convenience-store light beside ancient gate; highway rain beside a godlike rider.
- **Youth self-mockery under fate**: the protagonist reacts to apocalypse with mundane embarrassment, then slowly chooses courage.
- **Named visual motifs**: rain, neon, glass, black cars, sea, snow, old uniforms, weapon metal, campus lights, city announcements.
- **Information density**: world lore appears as pressure on the current scene, not as a lecture.
- **Emotional restraint**: characters rarely say the real thing directly. They talk about a meal, debt, lateness, equipment, or a joke.
- **Aftertaste**: the ending object matters — empty seat, repaired phone, unread message, ticket stub, vending-machine drink, sword in storage.

Avoid exact signature phrases, copied chapter titles, recognizable original sentences, and claims of official authorship.

## Set-Piece / Fight Craft

Fight scenes are not frequent filler. They should occur at hinge points and must change the story state.

Build each fight as a set piece:

1. **Space**: define the battlefield geometry — bridge lanes, subway platform, hotel corridor, shrine stairway, sea surface, lecture hall, icebreaker deck.
2. **Rule**: define the supernatural constraint — domain expansion, memory deletion, time lag, bloodline instability, weapon cost, dragon pressure, forbidden name.
3. **First impossible image**: one image that tells the reader reality has broken — rain rising upward, headlights freezing midair, glass orbiting a body, shadow moving before the person.
4. **Physical consequence**: wind pressure, shattered glass, buckled guardrail, hot shell casing, wet hair stuck to face, wrist numb from recoil.
5. **Character choice**: someone breaks the plan for another person; someone trusts; someone refuses a cheap victory.
6. **State change**: injury, lost memory, revealed identity, changed location, consumed weapon, countdown shortened, one person left behind.

If the fight does not produce a state change, cut or compress it.

## Ending Closure Model

A satisfying fanfic ending should answer emotional debts before encyclopedic mysteries.

Minimum closure set:

- Protagonist: what does he finally choose without being pushed?
- Missing / erased person: who remembers them, and what proves they existed?
- Key companion: what private wish is fulfilled, denied, or transformed?
- World: what changed visibly in ordinary life?
- Cost: what cannot be restored?
- Last object: what remains in the quiet after myth leaves?

## Writing Checklist Before Output

- Have I chosen a volume-mode: I-door, II-mission, III-foreign tragedy, IV-memory search, V-endgame?
- Does the scene have mission, identity, and youth-emotion engines?
- Are paragraphs mostly 2–5 sentences rather than one-line fragments or giant blocks?
- Is dialogue under control and embedded in narration?
- Is at least one image concrete enough to remember?
- If there is a fight, does it have space, rule, physical consequence, and state change?
- Does the ending leave an object / image rather than a lecture?
