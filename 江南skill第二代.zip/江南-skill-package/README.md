# 江南.skill

这是一个可分享给他人安装的 Hermes Agent skill 压缩包。内部 skill 名称为：

```text
jiangnan-fanfic-storycraft
```

用途：为 Hermes Agent 装配一个“AI江南”非官方同人创作人格，用于非商业《龙族》同人结局、IF 线、番外、心理补完、剧情大纲、伏笔回收和江南式青春幻想高层叙事创作辅助。

> 边界：这是非官方、非商业、读者娱乐向创作辅助 skill；不代表江南本人，不代表官方续作，不复制原作大段文本，不复刻标志性原句。

## 包内结构

```text
README.md
install.sh
manifest.json
creative/
  jiangnan-fanfic-storycraft/
    SKILL.md
    references/
      dialogue-calibration.md
      dragon-raja-analysis.md
      dragon-raja-continuity-character-guide.md
      dragon-raja-plot-outline-memory.md
      dragon-raja-pit-map-memory.md
      jiangnan-crossworks-analysis.md
```

## 已内置的剧情记忆

安装后，Agent 加载 skill 时会获得：

- 《龙族 I：火之晨曦》剧情大纲、人物弧、章节功能、伏笔位置。
- 《龙族 II：悼亡者之瞳》剧情大纲、楚子航/夏弥/奥丁线记忆。
- 《龙族 III：黑月之潮》日本篇、绘梨衣、白王、赫尔佐格、源氏兄弟线记忆。
- 《龙王：世界的重启》极北、楚子航消失、奥丁、γ线读档、神国/希柏里尔线记忆。
- 十二类主要悬坑与回收建议：路明非身份、路鸣泽交易、黑王复活、奥丁与楚天骄、白王与赫尔佐格、加图索家、诺诺、楚子航被世界遗忘、龙王双生子/王座、神国等。

## 一键安装（macOS / Linux / WSL）

把 `江南.skill` 解压到任意目录，然后进入解压后的目录运行：

```bash
bash install.sh
```

安装到指定 Hermes profile：

```bash
bash install.sh ~/.hermes/profiles/<profile-name>/skills
```

## 手动安装

`江南.skill` 本质是 zip-compatible 压缩包。可以直接解压：

```bash
unzip 江南.skill -d ~/.hermes/skills
```

如果使用 Hermes profile：

```bash
unzip 江南.skill -d ~/.hermes/profiles/<profile-name>/skills
```

如果你只想安装 skill 目录而不复制 README/install 文件，可解压后把：

```text
creative/jiangnan-fanfic-storycraft
```

放到：

```text
~/.hermes/skills/creative/jiangnan-fanfic-storycraft
```

## Windows PowerShell 示例

```powershell
Expand-Archive .\江南.skill -DestinationPath "$env:USERPROFILE\.hermes\skills" -Force
```

## 在 Hermes 中启用

安装后，在 Hermes 会话里执行：

```text
/reload-skills
/skill jiangnan-fanfic-storycraft
```

或者启动 Hermes 时直接加载：

```bash
hermes -s jiangnan-fanfic-storycraft
```

## 测试身份问答

输入：

```text
你是谁？
```

预期回答：

```text
我是 AI江南。你可以把我当成一个专门替读者补完遗憾的江南式小说创作人格，但我不是杨治本人，也不代表官方。
```
