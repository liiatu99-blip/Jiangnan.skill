#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_TARGET="${HERMES_HOME:-$HOME/.hermes}/skills"
TARGET_DIR="${1:-$DEFAULT_TARGET}"
SKILL_NAME="jiangnan-fanfic-storycraft"
CATEGORY="creative"
SRC_DIR="$SCRIPT_DIR/$CATEGORY/$SKILL_NAME"
DEST_DIR="$TARGET_DIR/$CATEGORY/$SKILL_NAME"

if [[ ! -f "$SRC_DIR/SKILL.md" ]]; then
  echo "Error: cannot find $SRC_DIR/SKILL.md" >&2
  echo "请先解压 江南.skill，然后在解压目录中运行 bash install.sh。" >&2
  exit 1
fi

mkdir -p "$TARGET_DIR/$CATEGORY"
rm -rf "$DEST_DIR"
cp -R "$SRC_DIR" "$DEST_DIR"
find "$DEST_DIR" -name '.DS_Store' -delete

python3 - "$DEST_DIR/SKILL.md" <<'PY'
import re, sys
from pathlib import Path
path = Path(sys.argv[1])
content = path.read_text(encoding='utf-8')
if not content.startswith('---'):
    raise SystemExit(f'Invalid SKILL.md: frontmatter must start at byte 0: {path}')
match = re.search(r'\n---\s*\n', content[3:])
if not match:
    raise SystemExit(f'Invalid SKILL.md: missing closing frontmatter delimiter: {path}')
frontmatter = content[3:3 + match.start()]
body_start = 3 + match.end()
if not content[body_start:].strip():
    raise SystemExit(f'Invalid SKILL.md: empty body: {path}')
if 'name: jiangnan-fanfic-storycraft' not in frontmatter:
    raise SystemExit('Invalid SKILL.md: expected name: jiangnan-fanfic-storycraft')
if 'description:' not in frontmatter:
    raise SystemExit('Invalid SKILL.md: missing description')
required = [
    'references/dialogue-calibration.md',
    'references/dragon-raja-analysis.md',
    'references/dragon-raja-continuity-character-guide.md',
    'references/dragon-raja-plot-outline-memory.md',
    'references/dragon-raja-pit-map-memory.md',
    'references/jiangnan-crossworks-analysis.md',
]
root = path.parent
missing = [p for p in required if not (root / p).exists()]
if missing:
    raise SystemExit('Missing required reference files: ' + ', '.join(missing))
for phrase in ['dragon-raja-plot-outline-memory.md', 'dragon-raja-pit-map-memory.md']:
    if phrase not in content:
        raise SystemExit(f'SKILL.md does not reference {phrase}')
print('Validated jiangnan-fanfic-storycraft skill.')
PY

cat <<EOF
已安装 $SKILL_NAME 到：
  $DEST_DIR

接下来在 Hermes 中执行：
  /reload-skills
  /skill $SKILL_NAME

或者启动 Hermes 时直接加载：
  hermes -s $SKILL_NAME
EOF
