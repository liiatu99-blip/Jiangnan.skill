#!/usr/bin/env python3
"""Audit generated Chinese prose for protected terms and repetition.

The script accepts .txt/.md/.docx files or directories. It reports:
- exact protected terms that should not survive originalization
- repeated paragraph openings
- repeated long sentences

It exits with status 1 when protected terms are found unless --warn-only is set.
"""

from __future__ import annotations

import argparse
import re
import sys
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET

DEFAULT_PROTECTED_TERMS = [
    "路明非",
    "路鸣泽",
    "楚子航",
    "诺诺",
    "陈墨瞳",
    "凯撒",
    "芬格尔",
    "绘梨衣",
    "老唐",
    "乔薇尼",
    "路麟城",
    "昂热",
    "弗拉梅尔",
    "贝奥武夫",
    "图灵",
    "苏恩曦",
    "酒德麻衣",
    "零",
    "雷娜塔",
    "赫尔佐格",
    "卡塞尔",
    "秘党",
    "末日派",
    "避风港",
    "黑天鹅港",
    "尼伯龙根",
    "言灵",
    "龙王",
    "黑王",
    "白王",
    "尼德霍格",
    "混血种",
    "屠龙",
    "血统",
    "王座",
    "王格",
    "龙族",
]


def read_docx(path: Path) -> str:
    parts: list[str] = []
    with zipfile.ZipFile(path) as archive:
        xml = archive.read("word/document.xml")
    root = ET.fromstring(xml)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    for para in root.findall(".//w:p", ns):
        texts = [node.text or "" for node in para.findall(".//w:t", ns)]
        if texts:
            parts.append("".join(texts))
    return "\n".join(parts)


def read_text(path: Path) -> str:
    if path.suffix.lower() == ".docx":
        return read_docx(path)
    return path.read_text(encoding="utf-8", errors="ignore")


def iter_files(paths: list[Path]) -> list[Path]:
    out: list[Path] = []
    for path in paths:
        if path.is_dir():
            for ext in ("*.docx", "*.txt", "*.md"):
                out.extend(sorted(path.rglob(ext)))
        elif path.suffix.lower() in {".docx", ".txt", ".md"}:
            out.append(path)
    return out


def split_paragraphs(text: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n+", text) if p.strip()]


def split_sentences(text: str) -> list[str]:
    raw = re.split(r"(?<=[。！？!?；;])", text)
    return [s.strip() for s in raw if len(s.strip()) >= 18]


def audit_file(path: Path, protected_terms: list[str], opener_len: int) -> dict:
    text = read_text(path)
    term_hits = {term: text.count(term) for term in protected_terms if term in text}

    paragraphs = split_paragraphs(text)
    openers = Counter()
    for para in paragraphs:
        cleaned = re.sub(r"\s+", "", para)
        if len(cleaned) >= opener_len:
            openers[cleaned[:opener_len]] += 1
    repeated_openers = {k: v for k, v in openers.items() if v >= 3}

    sentence_counts = Counter(split_sentences(text))
    repeated_sentences = {k: v for k, v in sentence_counts.items() if v >= 2}

    return {
        "path": str(path),
        "chars": len(re.sub(r"\s+", "", text)),
        "protected_terms": term_hits,
        "repeated_openers": repeated_openers,
        "repeated_sentences": repeated_sentences,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="+", type=Path)
    parser.add_argument("--protected-terms-file", type=Path)
    parser.add_argument("--opener-len", type=int, default=8)
    parser.add_argument("--warn-only", action="store_true")
    args = parser.parse_args()

    terms = DEFAULT_PROTECTED_TERMS
    if args.protected_terms_file:
        terms = [
            line.strip()
            for line in args.protected_terms_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]

    files = iter_files(args.paths)
    if not files:
        print("No .docx, .txt, or .md files found.", file=sys.stderr)
        return 2

    any_protected = False
    totals = defaultdict(int)
    for path in files:
        result = audit_file(path, terms, args.opener_len)
        print(f"\n== {result['path']} ==")
        print(f"chars: {result['chars']}")
        if result["protected_terms"]:
            any_protected = True
            print("protected terms:")
            for term, count in sorted(result["protected_terms"].items()):
                totals[term] += count
                print(f"  {term}: {count}")
        if result["repeated_openers"]:
            print("repeated paragraph openers:")
            for opener, count in sorted(result["repeated_openers"].items(), key=lambda x: (-x[1], x[0]))[:20]:
                print(f"  {opener}: {count}")
        if result["repeated_sentences"]:
            print("repeated long sentences:")
            for sent, count in sorted(result["repeated_sentences"].items(), key=lambda x: (-x[1], x[0]))[:20]:
                print(f"  {count}x {sent[:80]}")

    if totals:
        print("\nProtected-term totals:")
        for term, count in sorted(totals.items()):
            print(f"  {term}: {count}")

    return 0 if args.warn_only or not any_protected else 1


if __name__ == "__main__":
    raise SystemExit(main())
