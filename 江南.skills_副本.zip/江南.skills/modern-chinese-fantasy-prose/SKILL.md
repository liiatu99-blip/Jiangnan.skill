---
name: modern-chinese-fantasy-prose
description: >-
  Turn a user's idea, premise, outline, or rough scene into original Chinese
  article body text, prose, fiction scenes, dialogue, or chapter openings with a
  modern youth-fantasy sensibility: bittersweet coming-of-age, ordinary people
  facing mythic pressure, cinematic adventure, friendship, loneliness, courage,
  and reality-reflecting worldbuilding. Use when a user asks for
  Jiang Nan/江南-adjacent mood, Chinese fantasy prose, or "one idea to finished
  prose"; do not imitate Jiang Nan or any living author's exact style, persona,
  plots, characters, invented terms, or signature phrasing.
---

# Modern Chinese Fantasy Prose

## Core Boundary

Do not write "as Jiang Nan/江南", claim to be him, or imitate his exact living-author voice. Reframe exact-imitation requests as original modern Chinese fantasy prose shaped by broad, non-exclusive craft traits: youth, loneliness, courage, mythic scale, grounded city/school texture, and reflective emotional stakes.

Do not copy or closely paraphrase protected expression. Avoid Jiang Nan-specific characters, institutions, settings, invented terms, plot structures, catchphrases, and recognizable scene setups unless the user explicitly asks for criticism, summary, or factual analysis.

When the user asks for imitation, briefly say the output will be an original alternative rather than a direct style clone, then continue with the task.

## Source Notes

Use `references/research-notes.md` only when the user asks for research basis, style analysis, or a more source-informed pass. The notes summarize public interviews and reporting as craft principles, not as a style corpus.

Use `references/idea-to-prose.md` for the default workflow when the user gives a short idea and wants finished body text.

Use `references/originalization.md` when the user provides a franchise continuation, fan-work outline, or protected-world premise. Preserve only high-level emotional and structural beats, then create a new premise with original characters, factions, rules, and consequences.

Use `references/longform-output.md` when the user asks for many chapters, per-chapter length targets, sequential files, or Word document output. Follow its continuity-ledger and quality-gate workflow before final delivery.

Use `scripts/audit_text.py` after drafting or batch generation to scan `.docx`, `.txt`, or `.md` outputs for protected term residue and repetitive openings/sentences.

## Default Output Behavior

When the user provides a concept and asks for prose, produce finished正文 directly. Do not over-explain the technique unless the user asks. If the requested length is unspecified, draft a polished short piece around 1200-1800 Chinese characters. If the user specifies a word or chapter length, follow it.

If the user explicitly asks for "江南风格", do not claim exact imitation. Treat it as a request for an original modern Chinese youth-fantasy mood: lonely, cinematic, emotionally restrained, mythic pressure grounded in ordinary life.

## Writing Model

Build scenes from this pattern:

1. Anchor the scene in a concrete ordinary world: campus, dormitory, subway, rain-dark street, convenience store, hospital corridor, old apartment, terminal, office after midnight.
2. Introduce one impossible pressure: a relic, ritual, old pact, strange organization, historical echo, impossible creature, or unexplained rule.
3. Keep the viewpoint emotionally human. The central figure should want recognition, escape, belonging, forgiveness, or one more chance to protect someone.
4. Let courage arrive through relationship rather than power. Friends, family, memory, promises, and shame should matter more than spectacle.
5. Make fantasy reflect reality. The other world should reveal pressure already present in this one: class, loneliness, trust, institutions, ambition, betrayal, duty, or youth passing.
6. Close with consequence. Victory should cost something; loss should not be cheaply reversed; wonder should leave an aftertaste.

## Prose Guidance

Prefer a clean contemporary Chinese register with occasional lyric pressure. Use concrete sensory details before abstraction. Let emotional lines feel earned by action, not announced.

Use sentence rhythm deliberately:

- Short sentences for impact, embarrassment, fear, and banter.
- Longer sentences for memory, world history, and reflective turns.
- One quiet image can carry more weight than repeated adjectives.

Use humor sparingly as defense or self-mockery. Let characters joke when they are frightened or ashamed, then reveal the wound underneath.

Use cinematic movement without screenplay formatting: cut from a small object to a large event, from an ordinary noise to an impossible silence, from a casual line to a heavy choice.

## Dialogue And Voice

For fiction dialogue:

- Keep banter concise and character-specific.
- Let characters hide the real issue at first.
- Avoid speeches that explain the theme directly.
- Use understatement when emotions are large.

For reflective essay or interview-style prose:

- Use measured self-scrutiny, professional humility, and precise distinctions between craft, market, readers, and personal limits.
- Discuss writing as discipline, responsibility, and emotional necessity.
- Do not simulate Jiang Nan's personal biography or private experiences as first-person fact.

## Worldbuilding

Invent fresh systems. Draw from broad myth, history, science, religion, geography, and urban life, but transform the material enough that it has its own names, rules, and conflicts.

Use this test for invented concepts:

- Can the reader understand the rule through action, not exposition?
- Does the concept pressure the protagonist emotionally?
- Is it distinct from famous Jiang Nan-specific settings and terminology?
- Does it connect to the story's real-world theme?

## Originality Guardrails

Before finalizing, check:

- No Jiang Nan-specific names, institutions, species systems, magic terms, character arcs, or set-piece structures were reused.
- No direct imitation label remains in the output.
- No protected passage was paraphrased for rhythm or wording.
- The piece has a new premise, new relationships, and a new emotional problem.
- The output can be described as "modern Chinese youth fantasy" without naming a living author.

If the user's requested premise is too close to an existing work, change the premise while preserving only the broad emotional request.

## Quick Transform

When given a plain prompt, transform it like this:

1. Identify the emotional engine: loneliness, courage, shame, debt, farewell, first love, betrayal, or unfinished youth.
2. Pick an ordinary anchor and a fantasy pressure.
3. Draft one scene with restrained lyricism and concrete details.
4. Add one human reversal: a joke fails, a promise becomes costly, a coward takes one step forward, or a hero admits fear.
5. Run the originality guardrails.

## Batch Originalization

When converting a high-risk outline into original prose:

1. Read `references/originalization.md`.
2. Convert every chapter into neutral dramatic beats before drafting.
3. Build a replacement ledger for characters, factions, powers, settings, and endgame rules.
4. Read `references/longform-output.md` for chapter length, continuity, and document output requirements.
5. Draft in order, updating the ledger after each chapter.
6. Run `scripts/audit_text.py <output-path>` and revise any protected-term hits or obvious repetition.
