# Originalization Workflow

Use this reference when a user provides an outline, chapter plan, or fan-work premise tied to a living author, active franchise, or recognizable copyrighted world. The goal is to preserve high-level dramatic structure while creating an original work.

## Non-Negotiable Boundary

Do not generate a close continuation of an existing series. Do not keep protected character names, organizations, species systems, signature powers, invented places, iconic relationships, famous plot beats, or distinctive phrasing.

Noncommercial intent, fan-work framing, or an open ending does not remove this boundary. Continue by offering an original transformation.

## Transformation Steps

1. Extract the source outline into neutral beats:
   - scene function
   - emotional turn
   - conflict escalation
   - reveal or reversal
   - consequence
2. Remove franchise-specific nouns before drafting.
3. Create a new premise with its own:
   - protagonist wound
   - companion relationship
   - family conflict
   - institution or faction system
   - supernatural rule set
   - endgame cost
4. Rename and redesign every protected entity. Do not use one-to-one cosmetic renames when the surrounding role remains too recognizable; alter motivation, power logic, history, and relationship geometry.
5. Rebuild scene logic around the new rules, then draft original prose.
6. Run an originality pass with the audit script and the checklist below.

## Safe Preservation

It is acceptable to preserve:

- broad emotional arcs such as loneliness, courage, betrayal, farewell, sacrifice, and memory
- general structural roles such as protagonist, inner double, parent, mentor, rival faction, artificial intelligence, child key, or old archivist
- non-exclusive genre patterns such as dream/reality tension, institutional conflict, mythic pressure, and world-reset stakes
- chapter count, approximate pacing, and user-provided non-infringing titles

## Must Change

Change all of the following:

- names of characters, factions, schools, cities, experiments, powers, and artifacts
- the exact species or bloodline logic of the source franchise
- famous relationship configurations
- recruitment premises, academy premises, iconic battles, deaths, rescue structures, and signature reversals
- any phrase that feels recognizable as the source author's wording or the franchise's idiom

## Originalization Checklist

Before drafting:

- The story can be summarized without naming the source franchise.
- The protagonist's social identity, wound, and final choice differ from the source.
- The supernatural system has new rules and costs.
- The central factions have new origin logic and goals.
- The ending resolves the new premise, not the source canon.

After drafting:

- Search for protected names and terms.
- Search for repeated paragraph openings and repeated long sentences.
- Check that every chapter advances one new decision, reveal, or consequence.
- Remove apologetic or meta language from the creative output unless the user asked for notes.

## Example Replacement Pattern

Bad: "Same protagonist, same academy, same species conflict, renamed terms."

Better: "A failed provincial scholarship student discovers that dreams are archival contracts, not powers. An observatory-state and a disaster church both use sleeping children as keys. His inner double is not a demon but the half of him that remembers a prior erased world. The final choice is not to become king, but to erase the contract system while becoming its silent custodian."
