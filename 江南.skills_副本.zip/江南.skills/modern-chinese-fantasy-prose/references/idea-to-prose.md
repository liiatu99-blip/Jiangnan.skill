# Idea To Finished Prose

Use this reference when the user gives a short idea and wants finished Chinese body text.

## Default Contract

Produce original正文 directly. Do not write a long craft explanation before the piece. A compact title is acceptable when useful.

If the user asks for "江南风格", do not imitate a living author's exact style. Convert the request into an original modern Chinese youth-fantasy voice: ordinary life, mythic pressure, restrained lyricism, lonely humor, friendship, courage, and consequence.

Default length when unspecified: 1200-1800 Chinese characters.

## Input Expansion

Turn the idea into five working decisions:

1. Emotional engine: loneliness, shame, first love, farewell, betrayal, protection, debt, or courage.
2. Ordinary anchor: school, dormitory, convenience store, subway, hospital, old neighborhood, rain street, archive room, terminal, or office after midnight.
3. Impossible pressure: dream leak, forgotten pact, borrowed name, sleeping city, obsolete ritual, false memory, door that only one person can open, or an institution using someone as a tool.
4. Human relationship: friend, sibling-like double, parent, rival, mentor, stranger-child, or lost beloved.
5. Consequence: a promise costs something, the protagonist protects someone powerless, a memory is traded, a door closes, or victory creates solitude.

## Draft Shape

For a short finished piece:

1. Open with a concrete ordinary object or action, not abstract emotion.
2. Let the impossible enter quietly.
3. Use one or two lines of dialogue to expose the wound.
4. Give the protagonist a small but irreversible choice.
5. End on consequence, not explanation.

For a chapter opening:

1. Start with scene pressure.
2. Introduce the protagonist's immediate problem.
3. Establish the rule of the impossible.
4. Close with a hook that changes the situation.

For reflective prose:

1. Start from a concrete memory-like scene.
2. Move into a general observation about youth, fate, or courage.
3. Return to a specific human image.
4. Avoid pretending to be the real author.

## Language Guidance

Use clean contemporary Chinese with occasional lyric turns. Keep the emotional center under control; let images and choices carry feeling.

Prefer:

- specific objects over generic atmosphere
- restrained humor over exaggerated comedy
- short dialogue over explanation
- consequence over spectacle
- sensory detail over ornate modifiers

Avoid:

- repeated sentence openings
- overused phrases such as "命运的齿轮", "风像刀", "世界在这一刻安静下来"
- franchise-specific names, institutions, powers, species systems, or iconic setup patterns
- self-labeling the text as "仿江南"

## Final Pass

Before answering:

- The piece should read as正文, not outline.
- The central emotion should be legible without being explained.
- The supernatural rule should be clear through action.
- No living-author imitation claim should remain.
- No protected-world terms should appear unless the user asked for analysis rather than creation.
