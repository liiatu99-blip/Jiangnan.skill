# Research Notes: Public Jiang Nan Materials

These notes summarize public sources for craft analysis only. Do not treat them as a corpus for cloning a living author's style. Use them to support broad, original modern Chinese youth-fantasy writing.

Last reviewed: 2026-06-08.

## Source Map

- China Writers Association, 2018 interview: Jiang Nan, real name Yang Zhi, representative works include `龙族`, `九州缥缈录`, and `上海堡垒`; `龙族` began in 2009 and was published from 2010, with reported sales above 21 million by 2018. Source: https://www.chinawriter.com.cn/GB/n1/2018/0523/c405057-30006739.html
- China News / West China Metropolis Daily, 2016 interview: frames his success around not rushing, long-term belief in a work's future space, vision, and diligence; confirms writing remains the source of related company work. Source: https://www.chinanews.com.cn/m/cul/2016/03-22/7806183.shtml
- China Writers Association / Yangcheng Evening News, 2020 interview: describes `龙族` as having a youth imprint, says later understanding shifted toward lonely but vivid characters, treats writing as an inner harbor, and emphasizes that death or reversal must keep narrative weight. Source: https://www.chinawriter.com.cn/n1/2020/1025/c405057-31905087.html
- China Writers Association / The Paper, 2020 conversation: emphasizes courage for confused young readers, self-reflection around insecurity and loneliness, cross-cultural mythic recombination, and the need to supplement fantasy writing with reading and travel when knowledge runs thin. Source: https://www.chinawriter.com.cn/n1/2020/1022/c403994-31901491.html
- China Writers Association / Beijing Youth Daily, 2019 interview: positions fantasy as a way to reflect this world through another world; gives biographical context for early online-forum writing and a self-taught, "wild writer" path. Source: https://www.chinawriter.com.cn/n1/2019/0809/c405057-31284707.html
- Zhichanli, 2026 interview: focuses on copyright dispute and unfinished `龙族5`; emphasizes creative freedom, author dignity, and that literary works are not factory-standard industrial parts. Source: https://www.zhichanli.com/p/1457431017
- Hubei Copyright Protection and Service Network / China Intellectual Property News, 2026 legal commentary: summarizes the `龙族` publishing dispute as a case about trust, contract boundaries, and copyright licensing relationships. Source: https://www.ccct.net.cn/html/bqzx/2026/0509/6740.html

## Craft Principles Derived From Sources

Use these as broad heuristics, not as imitation instructions.

### Youth Fantasy Is Emotional Before It Is Mechanical

The cited interviews repeatedly frame youth fantasy around confusion, courage, and characters who feel isolated or ordinary. Use fantasy pressure to intensify a young person's need for belonging, responsibility, dignity, or escape. Avoid reducing growth to level-ups.

### Ordinary Texture Makes Myth Feel Larger

The strongest contrast comes from placing mythic or historical scale beside mundane places and behaviors. Start with a city, school, family, job, or late-night ordinary detail, then let the impossible arrive.

### The Other World Should Reflect This World

For original work, build fantasy systems that expose real concerns: trust, institutional pressure, class anxiety, failed promises, grief, or the cost of ambition. Do not make the invented world decorative only.

### Characters Carry The Long Arc

Sources describe the series' later center as lonely but vivid characters rather than only battles. Prioritize relationships, memory, and unresolved interior conflict over lore density.

### Consequences Need Weight

Treat loss, death, betrayal, and resurrection-like reversals carefully. A reversal must be justified by the story's rules and must deepen consequence rather than erase it.

### Writing Requires Knowledge Accumulation

Fantasy writing can require history, myth, geography, technology, and lived detail. If a scene needs specificity, research the relevant domain rather than filling it with generic grandeur.

### The Writer's Public Voice Is Reflective And Self-Limiting

In interviews, Jiang Nan often distinguishes commercial success from literary ambition and speaks about craft, doubt, responsibility to readers, and creative freedom. For an original reflective voice, use humility and exact distinctions, but do not simulate his personal experiences or first-person identity.

## Avoid List

Do not use these as generative building blocks unless the user is asking for factual discussion or critique:

- Names of Jiang Nan's characters, institutions, species systems, powers, and iconic locations.
- A setup that closely follows an ordinary underachieving teen being recruited into a dragon-related secret academy.
- Famous plot beats, deaths, romantic configurations, or battle structures from `龙族`, `九州缥缈录`, `上海堡垒`, or other named works.
- Recognizable slogans, catchphrases, or repeated emotional formulations.
- First-person claims that imply the assistant is Jiang Nan or has his lived experience.

## Safe Output Targets

- Original Chinese fantasy scene with a bittersweet coming-of-age mood.
- Original dialogue for young characters under mythic pressure.
- Outline for a new urban fantasy or historical-fantasy premise.
- Revision pass that adds grounded detail, emotional consequence, and cinematic pacing.
- High-level style analysis with citations, while avoiding direct imitation.
