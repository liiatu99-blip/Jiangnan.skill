# Longform Chapter Output Guide

Use this reference when turning an outline into many chapters, especially when the user requests per-chapter word counts, sequential files, or Word documents.

## Batch Workflow

1. Parse the outline into a chapter table:
   - chapter number
   - chapter title
   - summary
   - required beats
   - unresolved hooks
   - characters present
2. Create a continuity ledger before drafting:
   - renamed characters and factions
   - current location
   - active conflict
   - revealed secrets
   - pending promises
   - injuries, deaths, and irreversible costs
3. Draft chapters in order. Do not draft isolated scenes when the user asks for a continuous novel.
4. After each chapter, update the ledger with new facts.
5. Run quality and originality checks before creating final documents.

## Chapter Shape For 2500-3500 Chinese Characters

Aim for 7-10 substantial paragraphs. Avoid using identical paragraph templates across chapters.

Suggested internal rhythm:

1. Establish the immediate sensory situation.
2. Show the external action or pressure.
3. Let one character make or resist a decision.
4. Add dialogue that reveals the emotional problem indirectly.
5. Deliver the chapter's required reveal or reversal.
6. Show the cost through a concrete consequence.
7. End with a changed condition, not a generic cliffhanger.

For quieter chapters, replace external action with memory, investigation, moral argument, or dream logic, but still include a decision and consequence.

## Anti-Repetition Rules

Avoid repeated openings such as:

- "夜色很深"
- "所有人都沉默"
- "屏幕上跳动着"
- "风像刀"
- "他忽然明白"
- "这一刻"

Use varied sentence functions:

- observation
- physical action
- dialogue
- withheld thought
- environmental change
- institutional record
- memory fragment
- contradiction

Each chapter should introduce at least one fresh image or scene object: a cracked mug, obsolete badge, salt frost on a sleeve, a child monitor, a cafeteria light, an empty train seat, a folded medical consent form, a dead satellite phone, or a museum label.

## Dialogue Rules

- Do not make characters explain the whole plot aloud.
- Let dialogue carry pressure: accusation, evasion, bargaining, confession, or failed humor.
- Give each major character a distinct rhetorical habit.
- Break long exposition with interruption, physical business, or a visible consequence.

## Continuity Rules

- A reveal must change later behavior.
- A wound or sacrifice must leave a trace.
- If a faction changes position, give it a reason and a cost.
- Do not revive, erase, or reverse consequences unless the new supernatural rules explicitly justify it.
- Track who knows each secret. Do not let all characters suddenly share private information.

## Output Documents

When producing `.docx` chapter files:

- Use one file per chapter if requested.
- Name files exactly in sortable order, for example `第235章 沉吟至今（1）.docx`.
- Put all files in the requested folder.
- Use readable manuscript formatting: centered title, body paragraphs with first-line indent, comfortable line spacing, and no decorative clutter.
- If the output is large, generate a machine-readable manifest with chapter number, title, path, character count, and audit status.

## Quality Gate

Before final delivery:

- Verify the chapter count and chapter number range.
- Check approximate character count per chapter.
- Run protected-term and repetition scanning.
- Spot-check several chapter openings, middles, and endings.
- Render at least representative `.docx` files; render all when practical.
